<html>

<head>
    <!-- SISTEMTAIPE -->
    <!-- COPYRAING NO AUTORIZADO 2022
    ✅LINK DE SUSCRIPCION 👇
    https://tinyurl.com/y3ruj9rl -->

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=-1.5">
    <title>Sistema de Pedidos de Pizza y Hamburguesas</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="js/jquery.min.js"></script>

    <!-- jQuery code for implement logic for select pizza size and add toppings checkbox -->
    <script type="text/javascript">
    $(document).ready(function() {
        var size = 0;
        $('select').change(function() {
            size = ($(this).val());
            addValue(size);
        });
        addValue(size);

        function addValue(size) {
            var total = 0;

            function updateTextArea() {
                var allVals = [];
                $('#checkbox_container :checked').each(function() {
                    allVals.push($(this).val());
                });
                if (size === 0) {
                    size = 10;
                }
                total = parseFloat(size) + parseFloat(eval(allVals.join("+")));
                if (isNaN(total)) {
                    if (size === 0) {
                        total = 10;
                    } else {
                        total = size;
                    }
                }
                $('p#total span').html(" $ " + total);
            }
            $(function() {
                $('#checkbox_container input').click(updateTextArea);
                updateTextArea();
            });
        }
    });
    </script>

    <link rel="shortcut icon" href="./LOGOYOUTUBE.png" type="image/x-icon">
</head>

<body>
    <div id="main" >
        <div class="row">
            <center>
                <h1 class='text-info sistema_pedidos_tamano'> Sistema de Pedidos de Pizza y Hamburguesa</h1>
            </center>
            <div class="col-md-3"></div>
            <div class="col-md-6">

                <div class="panel panel-info">
                    <div class="panel-heading">
                        <h3 class='text-center'>Que Esperas haz tu Pedido Yaa</h3>
                    </div>
                    <div class="panel-body">
                        <img id="spizza" src="./fon01.png" class='img-responsive centrar' />
                        <form action="process.php" method="post">
                            <label class="centrar">Seleccion tu Comida Favorita:</label>
                            <select name="pizza_type" class="centrar-select">
                                <option value="10">Pizza Pequeña - $/. 10.00</option>
                                <option value="15">Pizza Mediana - $/. 15.00</option>
                                <option value="20">Pizza Gigante - $/. 20.00</option>
                                <option value=""><b>Hamburguesa</b></option>
                                <option value="12">Hamburguesa Doble - $/. 12.00</option>
                                <option value="8">Hamburguesa Clasico - $/. 8.00</option>
                                <option value="18">Hamburguesa Triple - $/. 18.00</option>
                            </select>
                            <br><br>
                            <center>
                                <h3>Agrega los Ingredientes que Desees. </h3>
                            </center>

                            <div id="checkbox_container" class="centrar aumentar-dimensiones">
                                <div id="chk">
                                    <p>Jamón</p>
                                    <input class="chk1" type='checkbox' name='topping1' value='2.00'
                                        id="topping1" /><label class="chk1" for="topping1"></label>
                                    <p>$ 2.00</p>
                                </div>
                                <div id="chk">
                                    <p>Pepperoni</p>
                                    <input class="chk2" type='checkbox' name='topping2' value='3.00'
                                        id="topping2" /><label class="chk2" for="topping2"></label>
                                    <p>$ 3.00</p>
                                </div>

                                <div id="chk">
                                    <p>Queso</p>
                                    <input class="chk4" type='checkbox' name='topping4' value='3.50'
                                        id="topping4" /><label class="chk4" for="topping4"></label>
                                    <p>$ 3.50</p>
                                </div>


                                <div id="chk">
                                    <p>Salami</p>
                                    <input class="chk5" type='checkbox' name='topping5' value='1.25'
                                        id="topping5" /><label class="chk5" for="topping5"></label>
                                    <p>$ 1.25</p>
                                </div>
                                <div id="chk">
                                    <p>Tocino</p>
                                    <input class="chk3" type='checkbox' name='topping3' value='2.25'
                                        id="topping3" /><label class="chk3" for="topping3"></label>
                                    <p>$ 2.25</p>
                                </div>
                                <div id="chk">
                                    <p>Pollo</p>
                                    <input class="chk6" type='checkbox' name='topping6' value='4.25'
                                        id="topping6" /><label class="chk6" for="topping6"></label>
                                    <p>$ 4.25</p>
                                </div>
                            </div>
                            <center>
                                <p id="total">Monto Total a Pagar : <span>$/. 20 </span></p>
                            </center>
                            <input type="submit" value=" Ordenar ahora " name="submit">
                        </form>

                    </div>
                </div>
                <div class='text-center'>
                    <img src="images/secure-paypal-logo.jpg" class='text'>

                    <h4 style="color: black; margin-bottom:-1%; background-color:white; padding:20px; border-radius:25px;" class="footer"> <strong> DESARROLLADOR LUIS VIÑA🏆 </strong></h4>

                </div>
            </div>
        </div>
    </div>


  
</body>

</html>

